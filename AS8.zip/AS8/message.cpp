#include "message.h"
#include <string>
#include <sstream>

using namespace std;

message::message() {
    wordnum = 0;
}

message::message(string s_temp) {
    wordnum = 0;
	s = s_temp;
}

const char * message::getWordByIndex(int index) {
    return ((words[index]).c_str());
}

void message::splitStringToWords() {
    stringstream ss;
    ss << s;
    while(ss >> words[wordnum]) {
        wordnum++;
    }
}

int message::getNumOfWords() {
    return wordnum;
}

void message::encodeMsg(char *c, int len) {
    for(int i = 0; i < wordnum; i++) {
        for(int j = 0; (j < words[i].length()) &&  (j < len); j++) {
            words[i][j] = words[i][j] + c[j];
        }
    }
}
