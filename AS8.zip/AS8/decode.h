#ifndef DECODE_H_INCLUDED
#define DECODE_H_INCLUDED

#include <iostream>
#include <string>
using namespace std;


class decode
{
public:
    decode();
    decode(string, string);
    void readthecode(string);
    void readthekey(string);
    void decodethefile();
    void outthefile();
    void setfilename(string);
    string getfilename();
    string words[10000];
     void setencodedfilename(string);
    string getencodedfilename();
    char seperator='@';
    string check="~";
    int a[10000];
    string arr[10000];
    string c;
    string h;
    int z;

};
#endif
