#ifndef MESSAGE_H_INCLUDED
#define MESSAGE_H_INCLUDED

#include <iostream>
#include <string>
using namespace std;

class message
{
    public:
        message();
        message(string s);
        const char * getWordByIndex(int index);
        void splitStringToWords();
        int getNumOfWords();
        void encodeMsg(char *c, int len);
    private:
        string s;
        string words[50];  //max 50 words per line.
        int wordnum;
};
#endif
