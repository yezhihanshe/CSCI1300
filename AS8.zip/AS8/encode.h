#ifndef ENCODE_H_INCLUDED
#define ENCODE_H_INCLUDED
#define ENCODE_H_INCLUDED

#include <iostream>
#include <string>
#include "message.h"
using namespace std;

class encode
{
    public:
        encode();
        encode(string);
        bool readfile(string);
        void readthekey(int);
        void encodefile();
        void writethekey();
        string seperate(string);
        void outthekey();
        void outencodefile();
        void setfilename(string);
        string getfilename();
        string c;
    private:
        char start_marker;
        char end_marker;
        char key[10];
        int keyLen;
        int wordsize;
        message msgs[200];  //max 200 lines per file.
        int linenum;
};

#endif
