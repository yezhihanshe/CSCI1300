#include <iostream>
#include "decode.h"
#include "encode.h"
#include <string>

using namespace std;

int main()
{
    int a;
    cout<<"welkcome to CSCI1300, if you want to encode, please enter 1, if you want to decode, please enter 2."<<endl;
      cin>>a;

    if(a==1)
    {
                   cout<<"Please enter the name of the file you want to encode: "<<endl;
 string v;
 cin>>v;
    encode mencode = encode(v);
    mencode.readthekey(1);
    mencode.encodefile();
      string a;
    mencode.setfilename(a);
    mencode.outencodefile();

    mencode.outthekey();
    }
    else if(a==2)
    {
            cout<<"Please enter the name of the file you want to decode: "<<endl;
    string c,d;
    cin>>c;
    cout<<"please enter the key of the file: ";
    cin>>d;
  decode test1= decode(c,d);
  string a;
    test1.setfilename(a);

    test1.decodethefile();
    test1.outthefile();
    }
}
