#include <iostream>
#include <string>
#include <fstream>
#include<stdlib.h>
#include "encode.h"
using namespace std;
encode::encode()
{
    wordsize=0;
    linenum = 0;
    keyLen = 0;
}

encode::encode(string file)
{
    linenum = 0;
    keyLen = 0;
    readfile(file);
}

bool encode::readfile(string filename)
{
    string line;
    // opeining file
    ifstream myfile(filename.c_str());
    if (myfile.is_open()){
        //Reading data of file to any array
        while(getline(myfile, line)){
            msgs[linenum] = message(line);
            msgs[linenum].splitStringToWords();
            linenum++;
        }
        myfile.close();
		return true;
	}
	else {
		cout << "Unable to open file";
		return false;
		exit(0);
	}
}

void encode::readthekey(int size)//read the keys in the txt
{
    cout<<"Please enter numbers of characters in the sentences include punction: " << endl;
    cin>>size;
    if(size>0)
    {

    keyLen = size;
    int i=0;
    cout<<"Please enter encode file.txt the key for sentences you want to encode, include punction." << endl;
    int word;
    for(; i<size; i++)
        {
        cin>>word;
        key[i]=word;
    }
    }
    else{
        cout<<"Please enter a number more than 0.";
        exit(0);
    }
}

void encode::encodefile()//encode the file
{int i = 0;
    while(i < linenum) {
        msgs[i].encodeMsg(key, keyLen);
        i++;
    }
}

void encode::setfilename(string a)
{
    cout<<"Please create a name of the encoded file: ";
    cin>>a;
   c=a;

   }

string encode::getfilename()
{
    return c;
}

void encode::outthekey() //write the key out
{
    string fname;
    fname="keys.txt";
    string path =  fname;
    ofstream out(path.c_str());
    int i;
    for( i = 0 ; i < keyLen; i++ )
    {
    out<<key[i] + 0 <<" ";
    }
    out.close();
}

void encode::outencodefile()//write the result out
{
        string fname;
        fname=c;
    string path =  fname;
    ofstream out(path.c_str());
    for(int i = 0; i < linenum; i++) {
        for(int j = 0; j < msgs[i].getNumOfWords(); j++) {
            out << msgs[i].getWordByIndex(j);
			out << '@';
        }
        out << endl;
    }
    out.close();
}
