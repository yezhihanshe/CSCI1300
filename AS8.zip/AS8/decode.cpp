#include <iostream>
#include <string>
#include <fstream>
#include <string>
#include <sstream>
#include "decode.h"
#include <stdlib.h>

using namespace std;
decode::decode()//read the encoded file
{
    z=0;
}
decode::decode(string filename,string keyname )
{
    readthecode(filename);
    readthekey(keyname);
}
void decode::readthecode(string filename)
{
    ifstream file;
    file.open(filename.c_str());
if (file.is_open())
    {
 int i = 0, j;
string str;
int found = 0, n;
while (getline(file, str)) {
if (found == 1) {
n = str.find(check);
if (n != -1) {
found = 1;
str = str.substr(0, n);
}
}
else {
n = str.find(check);
if (n != -1) {
found = 1;
str = str.substr(n + 1);
}
}
stringstream ss(str);
string token;
while (getline(ss, token, seperator)) {
words[i] = token;
z=i;
i++;
}
}
file.close();

}
else{
    cout << "Please put the encoded file into the Assignment8, and enter the right file name.";

}

}

 void decode::readthekey(string keyname)
{
    ifstream myfile;
    myfile.open(keyname.c_str());
// Main Metho

string line,word;
int i=0,splitWord=1;

// opeining file



if (myfile.is_open())
    {

//Reading data of file to any array

while(getline(myfile, line)){

//If you eanted to spilt words to each line as well

//then take first code otherwise else part

if(splitWord == 1){

//Stringstream: to split line to words

stringstream ss;

ss << line;

while(ss >> word){

a[i] = atoi(word.c_str());

i++;

}

}

}

myfile.close();

}

else

cout << "Please put the encoded file into the Assignment8, and enter the right key name.";


for(int j=0;j<z;j++){




}



}

void decode::decodethefile()//decode use ascii
{


int k = 0;
for(int i=0;i<z;++i)
    {
     string str = words[i];
     for(int j=0;j<str.size();++j)
     {
     str.at(j) = str.at(j) - a[k++];
      }
     arr[i] = str;
    }


}

void decode::setfilename(string a)
{
    cout<<"Please create a name of the decoded file: ";
    cin>>a;
   c=a;

   }

string decode::getfilename()
{
    return c;
}

void decode::outthefile()//write the rusult out
{
    string fname;
    fname=c;
    string path =  fname;
    ofstream out(path.c_str());
    int i;
    for( i = 0 ; i < z ; i++ )
    {
    out<<arr[i]<<" ";
    }
    out.close();
}


