# CS1300 Fall 2017
# Author: Hanye Han
# Recitation: <101 # Richard Tillquist>
# Assignment 10


#PART_1 functions here

def read_books(filename):
	try:#open the file
		f=open(filename)
		res=[]#set a new list
		for line in f:# loop all the lines in the file
			line=line.strip()#delete all the space
			data=line.split(',')#seperate the sentence by comma
			name=data[0] #store the value of author in name
			index=data[1]#store the name of book in index
			t=[]#create a new list
			t.append(index)#put the book name in the first position
			t.append(name)#author name in the second position
			res.append(t)#put the the list in a new list
		return res
	except:
		return None 

def read_users(filename):
    try:
    	f=open(filename)
    	res={}
    	for line in f:
        	arr = line.split()#seplit sentence by space
        	res[arr[0]] = list(map(int, arr[1:]))#set put the rating in the list as dictionary as value
    	return res
    except:
		return None

def calculate_average_rating(ratings_dict):
	l = list(ratings_dict.values())
	avgs = []
	for i in range(len(l[0])):#loop from 0 to the length of value at position at 0
		num = 0
		sum = 0
		for j in range(len(l)):#loop all the value in the dictionary
			if l[j][i] != 0:
				num = float(num + 1)
				sum = float(sum + l[j][i])
		avg = float(sum / num)
		avgs.append(avg)#store the average in a list
	return avgs

def lookup_average_rating(index, book_dict, avg_ratings_dict):
	return "(%.2f) %s by %s" % (avg_ratings_dict[index],book_dict[index][0],book_dict[index][1])#return a string

#PART_2 follow here

class Recommender:
    #Constructor here
	def __init__(self, book_file, rating_file):#set the defort value
		self.book_list = []
		self.average_rating_list = []
		self.user_dictionary = {}
		self.read_books(book_file)
		self.read_users(rating_file)
		self.calculate_average_rating()

	def read_books(self, file_name):
		try:
			f=open(file_name)
			for line in f:
				line=line.strip()#delete all the space
				data=line.split(',')#seperate by comma
				name=data[0]
				index=data[1]
				t=[]
				t.append(index)
				t.append(name)
				self.book_list.append(t)
		except:
			return None

	def read_users(self, file_name):
		try:
			f=open(file_name)
			res={}
			for line in f:
				arr = line.split()#seplit sentence by space
				self.user_dictionary[arr[0]] = list(map(int, arr[1:]))#set put the rating in the list as dictionary as value
		except:
			return None

	def calculate_average_rating(self):
		l = list(self.user_dictionary.values())
		for i in range(len(l[0])):#loop from 0 to the length of value at position at 0
			num = 0
			sum = 0
			for j in range(len(l)):#loop all the value in the dictionary
				if l[j][i] != 0:
					num = float(num + 1)
					sum = float(sum + l[j][i])
			avg = float(sum / num)
			self.average_rating_list.append(avg)#store the average in a list

	def lookup_average_rating(self, book_index):
		average_rating_string="(%.2f) %s by %s" %(self.average_rating_list[book_index],self.book_list[book_index][0],self.book_list[book_index][1])
		return average_rating_string

	def calc_similarity(self, user1, user2):
		list1 = self.user_dictionary[user1]#store the value of user1 in list 1
		list2 = self.user_dictionary[user2]#store the value of user2 in list2
		similarity_measure = sum ([i[0] * i[1] for i in zip(list1, list2)])#calculate the dot product of list1 and 2
		return similarity_measure

	def get_most_similar_user(self, current_user_id):
		largetDot = 0
		retUserKey = current_user_id
		for userKey, userValue in self.user_dictionary.items():
			if userKey!=current_user_id:
				if largetDot<self.calc_similarity(current_user_id, userKey):#if second user have high value
								largetDot = self.calc_similarity(current_user_id, userKey)#update the user
								retUserKey = userKey
								best_user_match_id= retUserKey
				elif largetDot==self.calc_similarity(current_user_id, userKey):#if they are equal 
					retUserKey=retUserKey#change nothing
					largetDot=largetDot
		return best_user_match_id

	def recommend_books(self, current_user_id):
		simid=self.get_most_similar_user(current_user_id)
		recommendations_list=[]
		list1=self.user_dictionary[current_user_id]
		list2=self.user_dictionary[simid]
		for g in range(len(list1)):#for all the values in the list1
			if list1[g]==0:#if user did not read the book
				if list2[g]==5 or list2[g]==3:#second user think it is good(give rating 3 or 5)
					recommendations_list.append(self.lookup_average_rating(g))#call lookup_average_rating and put the return in a list 
		return recommendations_list

def main():
	book_list = read_books("book.txt")
	user_dict = read_users("ratings.txt")
	ave_rating_list = calculate_average_rating(user_dict)
	print round(ave_rating_list[0], 3) 	# 3.833
	print ave_rating_list[20]  		# 0.5
	print lookup_average_rating(0, book_list, ave_rating_list)
	r = Recommender("book.txt", "ratings.txt")
	print r.lookup_average_rating(0)            # (3.83) The Hitchhiker's Guide To The Galaxy by Douglas Adams
	print r.calc_similarity('Cust8', 'Shannon')      # 369
	print r.lookup_average_rating(10)  	    #(0.90) The Princess Diaries by Meg Cabot
	print r.get_most_similar_user("Rudy.A")     # Cust8
	print r.recommend_books("Ella")
if __name__ == "__main__":
    main()