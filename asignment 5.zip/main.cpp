// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment5
#include <iostream>
#include "Assignment5.cpp"
using namespace std;

int main()
{

     float a[] = {10, 3, 4.6, 3.4, 2};
     int c[]={1,2,3,1,6};
     int d[]={4,3,9,1,2};
     float b[]= {1,2,3,4,5,6};
     cout<< "The sum of the arry is "<<sumArray(a,6)<<endl;

     cout<< "Number 20 is at "<<search(c, 6, 20)<<endl;
     cout<< "Number 1 is at "<<search(c, 6, 1)<<endl;
     cout<< "The squared differences of array c and d is "<<calculateDifference(c, d, 5)<<endl;
     cout<<"The middle value of array a is "<<findMedian (a, 5)<<endl;
     cout<<"The middle value of array b is "<<findMedian(b, 6)<<endl;
}
