// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment5
#include <iostream>
using namespace std;
#include <math.h>
//use for loop to add each number at all the index
float sumArray(float arry[], int size)
{
    float count =0;
    for (int i=0;i<size;i++)
    {

        count=count+arry[i];
    }
    return count;
}

//use for loop to check all the numbers in the array, if find target return the index
int search(int array[], int size, int target)
{
  int m=-1;
  for(int i = 0; i < size; i++)
    {
    if(array[i] == target)
    {
      m=i;
      break;//end the loop
    }
    }
  return m;
}
//find the difference at each index of that array and add them
float calculateDifference(int a[],int b[], int size)
{
    float total = 0;
    for(int i=0; i<size; i++)
    {
        total = total + pow(a[i]-b[i],2); //add all the number of a^2-b^2
    }
    return total;
}

void sortArray(float arr[], int n)
{
	for(int i = 1;i < n;i++)// i =1, because j=i-1
        {
		int temp = arr[i];
		int j = i - 1;
		while(temp < arr[j])//if arr[i]<arr[j]
        {
			arr[j+1] = arr[j];//array[i]=array[j], temp keep the value of array[i]
			j--;           //compare the value at j-1;
			if(j == -1)    //if array is at the element before the first one;
            {
				break;     //end the loop
			}
		}
		arr[j+1] = temp;   //value at array [i] = array[j]
	}
}
//copy from source to dest
void copyArray(float source[], int size, float dest[])
{
    for(int i = 0; i < size; i++)
  {
    dest[i] = source[i];  //copy from source to dest
  }
}

void convert(int rating[], string text[], int size)
{
    for(int i=0;i<size;i++)
    {
        if (rating[i]==0)  //if rating =0
        {
            text[i]="Not-read";//text at that position is not-read
        }
        else if(rating[i]==-5)
        {
            text[i] = "Terrible";
        }
        else if (rating[i] == -3)
        {
            text[i]= "Disliked";
        }
        else if (rating[i]==1)
        {
            text[i]="Average";
        }
        else if(rating[i] == 3)
        {
            text[i] = "Good";
        }
        else if(rating[i] == 5)
        {
            text[i] = "Excellent";
        }
        else                     //if can not find the value in rating
        {
            text[i] = "INVALID";  //text at that position is invalid
        }
    }
}

float findMedian (float array[], int size)
{
    int c=size%2;  //define array is odd or even
    int d=size/2;   //find the middle number in a int value
    float m;
    float array2[size];
    copyArray(array, size, array2);
    sortArray(array2, size);
    if (c==0)       //if array is even
    {
       m=(array2[d]+array2[d-1])/2;
    }
    else
    {
        m= array2[d];//if it is odd
    }
    return m;
}

