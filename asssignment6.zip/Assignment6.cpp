// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment6
#include <iostream>
#include <fstream>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iostream>
#include <fstream>
#include <sstream>
# include <iostream>
# include <fstream>
# include <iomanip>
# include <string>
#include<stdlib.h>


using namespace std;

using namespace std;
float tempArray[1000][5];
float avgCharsPerLine(string filename)
{
ifstream myfile;
myfile.open(filename.c_str());// opening file for reading
string str;
float sum = 0, averag;
int count = 0;
while(getline(myfile,str))//read from ifstream and put value in str
{
sum+=str.length();
count++;
}

averag = sum/count;
myfile.close();
return averag;
}

int fillArray(string filename,float array[][5])
{
ifstream myfile;
myfile.open(filename.c_str());// opening file for reading
string str;
int count = 0;
getline(myfile,str);//read the first line

// reading rest of the file line by line
while(getline(myfile,str))
{
// convert str to int
std::stringstream ss(str);

float num;
for(int i=0;i<5,ss>>num;i++)
{
array[count][i] = num;
if (ss.peek() == ',')
ss.ignore();
}
count++;
}
return count;
}
float arrayStats (string filename, float numbers[][5]){

    int num_row = fillArray(filename, numbers);

    float arr_mean[num_row];
    int i = 0;
    float temp_sum = 0;

    for ( int col = 1; col < 5; col=col+2){
        for ( int row = 0; row < num_row; row++){
            temp_sum = temp_sum + numbers[row][col];
        }
        arr_mean[i] = temp_sum / num_row;
        temp_sum = 0;
        i++;
    }

    for ( int row = 1; row < num_row; row=row+2){
        for ( int col = 0; col < 5; col++){
            temp_sum = temp_sum + numbers[row][col];
        }
        arr_mean[i] = temp_sum / 5;
        temp_sum = 0;
        i++;
    }

    float sum = 0;
    for (int j = 0; j < i; j++){
        sum = sum + arr_mean[j];
    }
    return sum;
}

void addBookRatings(string filename, string users[],int ratings[][50]){


               ifstream File;

               File.open(filename.c_str());



               string name;

               int Id,rate,i;



               string line;

               getline(File, line); //read the first line


               while (getline(File, line))//read from second line

               {

                   istringstream iss(line);//read from string


                   string delimiter = ",";

                              name = line.substr(0, line.find(delimiter)); //find the name for  user

                              line.erase(0,line.find(delimiter)+1);//remove name

                              Id = atoi (line.substr(0, line.find(delimiter)).c_str());//find the id for  user and convert to int

                              line.erase(0,line.find(delimiter)+1); //remove book_id

                              rate = atoi (line.c_str()); //rating converted int



                              //find the user index in users array

                              //if not found plus one

                              for(i=0;i<100;i++){

                                             if(!users[i].empty()){

                                                            if(name == users[i])

                                                                           break;

                                             }

                                             else{

                                                            users[i] = name;

                                                            break;

                                             }

                              }

                              //add rating in corresponding place

                              //book_id range is 0 to 49

                              if(ratings[i][Id]==0)

                                             ratings[i][Id] = rate;

               }

}
