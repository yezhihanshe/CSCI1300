// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment6
#include <iostream>
#include "Assignment6.cpp"
using namespace std;

int main()
{

  float array[10][5];
     cout<<  avgCharsPerLine("1.txt")<<endl;

    cout<< fillArray("1.txt",array)<<endl;
    cout<<arrayStats ("1.txt", array)<<endl;

}
