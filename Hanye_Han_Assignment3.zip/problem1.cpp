// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment 3
// Problem <1>
#include <iostream>
using namespace std;
/**
* Algorithm description:
* let user to enter a number from 123, if enter 1 call story1. if enter 2 call story2,if enter 3, call story3
* if enter q, break the loop,and exit.
* inside each function print the user entered, and make a sentence.
*
*/
void story1(void)
{
cout<<"Enter a plural noun: ";
string n;
cin>>n;
cout<<"Enter an occupation: ";
string c;
cin>>c;
cout<<"Enter an animal name: ";
string a;
cin>>a;
cout<<"Enter a place: ";
string p;
cin>>p;
cout<<"In the book War of the "<<n<<", the main character is an anonymous "<<c<<" who records the arrival of the "<<a<<"s in "<<p<<"."<<endl;
}
void story2(void)
{
cout<<"Enter a name: ";
string n;
cin>>n;
cout<<"Enter a state/country: ";
string c;
cin>>c;
cout<<n<<", I've got a feeling we're not in "<<c<<" anymore."<<endl;
}
void story3(void)
{
cout<<"Enter a first name: ";
string n;
cin>>n;
cout<<"Enter a relative: ";
string c;
cin>>c;
cout<<"Enter a verb: ";
string a;
cin>>a;
cout<<"Hello. My name is "<<n<<". You killed my "<<c<<". Prepare to "<<a<<"."<<endl;
}
void menu (void)
{

    while(1)
    {
        cout<<"Which story would you like to play? Enter the number of the story (1, 2, or 3) or type q to quit: "<<endl;
        string a;
    cin>>a;
    if (a=="q")
    {
         cout<<"good bye";
         break;
    }
    else if (a=="1")
    {
    story1();
    }
    else if (a=="2")
    {
        story2();
    }
    else if (a=="3")
    {
        story3();
    }
    else
    {
    cout<<"Valid choice not selected."<<endl;
    }
    }
}

int main()
{

   menu();
}
