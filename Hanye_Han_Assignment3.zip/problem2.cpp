// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment 3
// Problem <2>
/**
* Algorithm description:
* in main function ask user to enter 2 number then call windchillcalculator to find the wind chill, print the answer at the main function.
*
*
*
*/
#include <iostream>
using namespace std;
#include <math.h>

float windChillCalculator(float T, float V)
{
  float f;
  f=35.74+0.6215*T-35.75*pow(V,0.16)+0.4275*T*pow(V,0.16);
  return f;
}
void printWindChill(float T,float l,float h,float s)
{
    float i=l;                 //set the lowest speed as i
    while (i<=h)               //when i<highest speed ,it continue,
    {
         windChillCalculator( T, i); //call the function  windChillCalculator
        cout << "The wind chill is " << windChillCalculator( T, i) << " degrees F for an airtemperature of " << T << " degrees F and a wind speed of " << i << " mph." << endl;
        i=i+s;//add the wind_speed_step to the i(lowest temperature), then i become a new i,
}
}
int main()
{

 float T;
 float V;
 cout<<"Enter the air temperature: ";
 cin>>T;
 cout<<"Enter the wind speed: ";
 cin>>V;
windChillCalculator(T,V);
 cout<<"The wind chill is " <<windChillCalculator(T,V)<<" degrees F."<< endl;

}
