// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment4
#include <iostream>
using namespace std;

float similarityScore(string sequence1, string sequence2)
{
    int i=0;
    float same=0;
    int l =sequence1.length();
    if ( sequence1.length()!=sequence2.length())
    {
        return 0;
    }
    else
    {
        while (i<sequence1.length())   //only compare when sequence1 == sequence 2, if sequence[i]==sequence2[i], add one;
        {
            if (sequence1[i]==sequence2[i])// find similarity_score = (string length - hamming distance) / string length
            {
                same=same+1;
            }
            else
            {
               same=same;
            }
         i=i+1;
        }
        return same/l;
    }
}

int countMatches (string genome, string sequence1 , float min_score)
{
    int i =0;
    int c=0;
    int l = sequence1.length();
    int z = l+i;
    while (i+l<=genome.length())      //position of genome[i]+length of sequence1should smaller than and equal to the length of genome
    {
        if (similarityScore(genome.substr(i,l),sequence1)<min_score)
         {
             c=c;
         }
        else                              //count the number only if the score of similarityScore(genome.substr(i,l),sequence1) is greater than min_score
        {
           c=c+1;
      }
      i=i+1;
    }
    return c;
}

float findBestMatch (string genome, string seq)
{
    int i =0;
    float h=0;
    int s=0;
    int l = seq.length();
    int z = seq.length()+i;
    while (i+l<=genome.length())        //position of genome[i]+length of sequence1should smaller than and equal to the length of genome
    {
        if (similarityScore(genome.substr(i,l),seq)<h)   // if score small than the last score, keep the last score
         {
             h=h;
         }
        else
        {
           h=(similarityScore(genome.substr(i,l),seq));  //else use the latest score
      }
      i++;
    }
    return h;
}

int findBestGenome (string genome1, string genome2, string genome3, string seq)
{
     if ( (findBestMatch (genome1, seq) > findBestMatch (genome2, seq) )&& (findBestMatch (genome1, seq) >findBestMatch (genome3, seq) )) //if the score of gebome 1 is greater than others
    {
        return 1;
    }
    else if  ( (findBestMatch (genome3, seq) > findBestMatch (genome1, seq)) && findBestMatch (genome3, seq) >(findBestMatch (genome2, seq)) ) //if the score of gebome 3 is greater than others
    {
        return 3;
    }
    else if ( (findBestMatch (genome2, seq) > findBestMatch (genome1, seq)) && (findBestMatch (genome2, seq) > findBestMatch (genome3, seq)) )  //if the score of gebome 2 is greater than others
    {
        return 2;
    }
    else                                //if two genome equal to each other
    {
        return 0;
    }

}
