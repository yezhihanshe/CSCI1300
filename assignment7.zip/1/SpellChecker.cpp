// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment7

#include <iostream>
#include <string>
#include <fstream>
#include "SpellChecker.h"
using namespace std;

SpellChecker::SpellChecker(){

}

SpellChecker::SpellChecker(string lan){
    language = lan;
}

SpellChecker::SpellChecker(string lan, string validfile, string correctfile){
    language = lan;
    readValidWords(validfile);
    readCorrectedWords(correctfile);
}

SpellChecker::~SpellChecker(){

}
//open file and save each line in the array

bool SpellChecker::readValidWords(string validfile){
    ifstream inStream;
    inStream.open(validfile.c_str());
    if (!inStream.is_open()){
        return inStream.is_open();
    }

    string line;
    int count = 0;
    while(getline(inStream,line)){
                valid[count] = line;
                count++;

    }
    inStream.close();
    return count != 0;
}
//open the file, save the incorrect words, and correct words into array
bool SpellChecker::readCorrectedWords(string correctfile){
    ifstream inStream;
    inStream.open(correctfile.c_str());
    if (!inStream.is_open()){
        return inStream.is_open();
    }

    string line;
    int pos = 0;
    while(getline(inStream,line)){
        if(line.length()>0){
                pos = line.find('\t');
                for (int i = 0; i < 10000; i++){
                    if(incorrect[i].length() == 0){
                        incorrect[i] = line.substr(0,pos);
                        correct[i] = line.substr(pos+1,line.length()-(pos+1));
                        break;
                    }
                }

        }
    }
    inStream.close();
    return pos != 0;
}

bool SpellChecker::setStartMarker(char startmkr){
    start_marker = startmkr;
    return start_marker == startmkr;
}

bool SpellChecker::setEndMarker(char endmkr){
    end_marker = endmkr;
    return end_marker == endmkr;
}

char SpellChecker::getStartMarker(){
    return start_marker;
}

char SpellChecker::getEndMarker(){
    return end_marker;
}

string SpellChecker::removePunLow(string sent){
int i = 0;
    while ( i < pun.length() ){
        if(sent[0] == pun[i]){
            sent = sent.substr(1,sent.length()-1);
            break;
        }
        i++;
    }
             //delete the punctuation in the first position

int j = 0;
    while ( j < pun.length() ){
        if(sent[sent.length()-1] == pun[j]){
            sent = sent.substr(0,sent.length()-1);
            break;
        }
        j++;
    }
         //delete the punctuation in the last position

    for (int z = 0; z < sent.length(); z++){
        if (sent[z] >= 'A' && sent[z] <='Z'){
            sent[z] = (char)tolower(sent[z]);
        }
    }
    return sent;
}    // turn character into lower case

//correct the wrong words
string SpellChecker::repair(string sentence){
    string line;
    string sub;
    int count = 0;
    for (int i = 0; i < sentence.length(); i++){
        if(sentence[i] != ' '){
            sub = sub + sentence[i];
        }
        if (sentence[i] ==' ' || i == sentence.length()-1){
            bool is_valid = false;
            sub = removePunLow(sub);
            for(int j = 0; j < 10000; j++){
                if (sub == valid[j]){
                    is_valid = true;
                    break;
                }
            }
            if(is_valid != true){
                bool is_incorrect = false;
                for(int k = 0; k < 10000; k++){
                    if (sub == incorrect[k]){
                        sub = correct[k];
                        is_incorrect = true;
                        break;
                    }
                }
                if(is_incorrect != true){
                    sub = start_marker + sub + end_marker;
                }
            }
            if(count == 0){
                line = sub;
            } else {
                line = line + " " +sub;
            }
            sub = "";
            count++;
        }
    }
    return line;
}
//write the correct words out
void SpellChecker::repairFile(string input, string output){
    ifstream text;
    ofstream out;
    text.open(input.c_str());
    out.open(output.c_str());
    string line;
    while(getline(text,line)){
        out << repair(line) << endl;
    }
    text.close();
    out.close();
}
