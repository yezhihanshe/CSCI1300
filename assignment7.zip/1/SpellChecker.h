// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment7
#ifndef SPELLCHECKER_H_INCLUDED
#define SPELLCHECKER_H_INCLUDED

#include <iostream>
#include <string>
using namespace std;

class SpellChecker{
    public:
        SpellChecker();
        SpellChecker(string);
        SpellChecker(string, string, string);
        ~SpellChecker();

        string language;

        bool readValidWords(string);
        bool readCorrectedWords(string);
        bool setStartMarker(char);
        bool setEndMarker(char);
        char getStartMarker();
        char getEndMarker();
        string repair(string);
        void repairFile(string, string);


    private:

        char start_marker;
        char end_marker;
        string valid[10000];
        string incorrect[10000];
        string correct[10000];
        string pun = "!@#$%^&*()_-+={}[]:;''?/<>,.";

        string removePunLow(string);
};

#endif // SPELLCHECKER_H_INCLUDED

