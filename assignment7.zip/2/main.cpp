#include "WordCounts.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    WordCounts test;
    test.tallyWords("when where what");
        cout<<test2.getTally("where");

    return 0;
}
