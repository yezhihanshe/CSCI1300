// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment7
#ifndef WORDCOUNTS_INCLUDED
#define WORDCOUNTS_INCLUDED

#include <iostream>
#include <string>
using namespace std;

class WordCounts{
    public:
        WordCounts();
        ~WordCounts();

        void tallyWords(string);
        int getTally(string);
        void resetTally();
        int mostTimes(string[], int[], int);


    private:
        string words[10000];
        int wordcount[10000];
        string pun = "!@#$%^&*()_-+={}[]:;''?/<>,.";

        string removePunLow(string);
};


#endif // WORDCOUNTS_INCLUDED
