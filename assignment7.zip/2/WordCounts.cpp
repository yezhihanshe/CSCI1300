// Author: <hanye han>
// Recitation: <101 # Richard Tillquist>
//
// Assignment7

#include "WordCounts.h"
#include <iostream>
#include <string>
using namespace std;

WordCounts::WordCounts(){

}

WordCounts::~WordCounts(){

}
//remove the punctuation,

string WordCounts::removePunLow(string s){
    string l;
    int i=0;
    while ( i < s.length())
    {

        bool test=false;
        for (int j = 0; j < pun.length(); j++){
            if(s[i] == pun[j]){
                test = true;
                break;
            }
        }
        if (test != true && (s[i] < 'A' || s[i] > 'Z'))
            {
            l = l + s[i];

        }
        if (test != true && s[i] >= 'A' && s[i] <='Z'){
            l = l + (char)tolower(s[i]);
        }
        i++;
    }
    return l;
}

//take in a string of multiple words,remove the punctuation, and increment the counts for all words in the string

void WordCounts::tallyWords(string s){
    string news = removePunLow(s);
    string sub;
    int i=0;
    while( i < news.length())
        {
        if(news[i] != ' '){
            sub = sub + news[i];
        }
        if (news[i] ==' ' || i == news.length()-1){
                int dummy = -1;
                for (int j = 0; j < 10000 && words[j].length()>0; j++){
                    if (sub == words[j]){
                        wordcount[j] = wordcount[j] + 1;
                        dummy = j;
                        break;
                    }
                }
                if (dummy = -1){
                        for (int k = 0; k < 10000; k++){
                            if(words[k].length() == 0){
                                words[k] = sub;
                                wordcount[k] = 1;
                                break;
                            }
                        }
                }
                sub ="";
        }
    i++;
    }
    return;
}
//return the current count of the given word. If the word is not find found to be in the current list of words, return 0.

int WordCounts::getTally(string wd){
    int i=0;
    while(i < 10000)
        {
        if(words[i] == wd){
                return wordcount[i];
        }
    i++;
    }
}

void WordCounts::resetTally(){
    int i=0;
        while( i < 10000 ){
        wordcount[i] = 0;
        i++;
    }

}
//find the n most common words in,the text that has been counted and return those words and counts in via the arrays given as parameters.the text that has been counted and return those words and counts in via the arrays given asparameters

int WordCounts::mostTimes(string mostw[],int mostc[], int input_size){
    for (int i = 0; i < input_size; i++){
        int index = i;
        for(int j = i+1; j < 10000 && words[j].length()>0; j++){
  if (wordcount[j] > wordcount[index])
  {                index = j;
            }
        }

        if( index != i){
                string temp_word = words[i];
                int temp_count = wordcount[i];
                words[i] = words[index];
                wordcount[i] = wordcount[index];
                words[index] = temp_word;
                wordcount[index] = temp_count;
        }
        mostw[i] = words[i];
        mostc[i] = wordcount[i];
    }
    return 0;
}
