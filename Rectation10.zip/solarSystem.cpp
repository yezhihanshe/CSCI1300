
#include "planet.h"
#include "solarSystem.h"
#include "math.h"

solarSystem::solarSystem(string name) {
    systemName = name;
}

solarSystem::~solarSystem() {

}

string solarSystem::getName() {
    return systemName;
}

int solarSystem::getNumPlanets() {
    return numPlanets;
}

bool solarSystem::addPlanet(string planetName, float planetRadius)
{
    for (int i = 0; i < numPlanets; i++) {
        if (systemPlanets[i].getName() == planetName)
            {
            return false;
        }
    }
    systemPlanets[numPlanets] = planet(planetName, planetRadius);
    numPlanets++;
    return true;
}

planet solarSystem::getPlanet(int index){
    return systemPlanets[index];
}


float solarSystem::radiusDifference(planet p1, planet p2) {
    return fabs(p1.getRadius() - p2.getRadius());

}
