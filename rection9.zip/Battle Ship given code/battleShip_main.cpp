#include <iostream>
#include "battleShip.h"
#include "battleShip.cpp"

using namespace std;

int main(){
	//TODO: Declare 3 instances of the battleship class: Destroyer Carrier Cruiser

	battleShip one("Destroyer");
    battleShip two("Carrier");
	battleShip three("Cruiser");

	cout << one.getShipName() << endl;
	cout << two.getShipName() << endl;
	cout << three.getShipName() << endl;

	//TOD0: Give the ships a size: Destroyer-3 Carrier-5 Cruiser-2
	// you will need to call the appropriate methods

	one.setSize(3);
	two.setSize(5);
	three.setSize(2);
	cout << one.getSize() << endl;
	cout << two.getSize() << endl;
	cout << three.getSize() << endl;


	// Once you have this running for one, expand this while loop to include the other
	// two instances. Have the while loop end when all three ships have been sunk
	while(one.isSunk() == false || two.isSunk() == false || three.isSunk() == false){
		if(one.isSunk() == false) {
			one.recordHit();
		}
		if(two.isSunk() == false) {
			two.recordHit();
		}
		if(three.isSunk() == false) {
			three.recordHit();
		}
	}
}
