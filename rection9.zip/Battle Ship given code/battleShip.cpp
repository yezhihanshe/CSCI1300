#include <iostream>
#include <string>
#include "battleShip.h"

using namespace std;

battleShip::battleShip(string sname) {
  name = sname;
}

battleShip::~battleShip() {

}

void battleShip::setShipName(string nname) {
  name = nname;
}

string battleShip::getShipName() {
  return name;
}

void battleShip::setSize(int nsize) {
  size = nsize;
}

int battleShip::getSize() {
  return size;
}

void battleShip::recordHit() {
  hits=hits+1;
}

bool battleShip::isSunk() {
  if (hits < size) {
    return false;
  } else {
    return true;
  }
}
