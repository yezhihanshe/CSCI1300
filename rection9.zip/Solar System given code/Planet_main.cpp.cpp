#include <iostream>
#include "planet.h"
#include "planet.cpp"
// TODO: Include the header files for the planet class (part 2) and the solar system class (part 3)

using namespace std;

int main(){
    
    /// Part 2: Planets
    planet p[4];
    
    p[0].setName("Mercury");
    p[0].setRadius(2440);
    p[0].setDist(0.387);
    p[1].setName("Venus");
    p[1].setRadius(6052);
    p[1].setDist(0.723);
    p[2].setName("Earth");
    p[2].setRadius(6371);
    p[2].setDist(1.000);
    p[3].setName("Mars");
    p[3].setRadius(3390);
    p[3].setDist(1.524);
    
    //TODO: Declare 4 instances of the planet class, using the following table for reference
    
    // Use the following print statements to test your planet class code
    for(int i = 0; i < 4; i++)
    {
        cout << "The orbit of " << p[i].getName();
        cout << " takes " << p[i].getOrbitPeriod() << " years." << endl;
        cout << "The diameter of " << p[i].getName();
        cout << " is " << p[i].getDiameter() << " km." << endl;
        cout << p[i].getName() << " is " << p[i].getDist() << " AU from the Sun." << endl;
        cout << " --- " << endl;
    }
}

//planet.h
